﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ftp_client
{
    public enum Message_Type
    {
        req_Message,
        resp_Message,
        result_Message
    }
    class FileTransfer
    {
        const int port = 9003;
        public delegate void FileDownComplete(bool complit, string complitMsg);
        public delegate void CurrentFileDownState(int percent, string totalPerCurrent);

        public event FileDownComplete FileDownCompleteEvent;
        public event CurrentFileDownState FildDownCurrent;
        public FileTransfer()
        {

        }
        public void setFilePath(string _path)
        {
            path = _path;
        }
        string path;
        static uint msgid = 0;


        public void Down(string _fileUrl, string _url = "192.168.0.110")
        {
            string url = _url;
            IPEndPoint clientAddress = new IPEndPoint(0, 0);
            IPEndPoint serverAdress = new IPEndPoint(IPAddress.Parse(url), port);

            TcpClient client = null;

            try
            {
                ConnectInfo info = new ConnectInfo();
                client = new TcpClient(clientAddress);
                info.client = client;
                info.fileName = _fileUrl;
                client.BeginConnect(url, port, new AsyncCallback(filedownloadstartCallback), info);

            }
            catch (Exception ex)
            {
                if (client != null) client.Close();
            }
        }
        private async void filedownloadstartCallback(IAsyncResult _responeResult)
        {
            ConnectInfo info = (ConnectInfo)_responeResult.AsyncState;  // 클라이언트 인스턴스 생성

            TcpClient client = info.client;
            string filepath = info.fileName;    // 클라이언트 정보 할당

            NetworkStream stream = null;
            FileStream file = null;

            try
            {
                stream = client.GetStream();
                byte[] fileName = Encoding.Default.GetBytes(filepath);

                #region Request 메시지 전송
                client_Message request_Msg = new client_Message();
                Message_Set(Message_Type.req_Message, request_Msg, fileName);
                // 클라이언트는 서버에 접속하자마자 파일 전송 요청 메시지를 보낸다.
                MessageUtil.Send(stream, request_Msg);
                #endregion

                #region Request 메세지에 대한 응답 수신
                request_Msg = await MessageUtil.ReceiveVideo(stream);
                #endregion

                if (request_Msg.Header.MSGTYPE != CONSTANTS.REQ_FILE_SEND)//파일 없음 or 전송 시작 시퀀스 예외발생
                {
                    FileDownCompleteEvent?.Invoke(false, "");
                    stream.Close();
                    client.Close();
                    return;
                }

                #region Response 메시지 전송
                client_Message response_Msg = new client_Message();
                Message_Set(Message_Type.resp_Message, response_Msg);
                MessageUtil.Send(stream, response_Msg);   // 클라이언트 Response_MSG  전송
                #endregion  


                BodyRequest reqBody = (BodyRequest)request_Msg.Body;
                long fileSize = reqBody.FILESIZE;


                #region 파일 수신
                // 파일 스트림 생성
                file = new FileStream(path, FileMode.Create);

                request_Msg = await MessageUtil.ReceiveVideo(stream);

                fileDownload(request_Msg, file, stream, fileSize);

                long recvFileSize = file.Length;

                file.Close();
                #endregion
                Console.WriteLine();
                Console.WriteLine("수신 파일 크기 : {0} bytes", recvFileSize);


                #region Result 메시지 전송
                client_Message result_Msg = new client_Message();
                Message_Set(Message_Type.result_Message, result_Msg);

                if (fileSize == recvFileSize)
                    // 파일 전송 요청에 담겨온 파일 크기와 실제로 받은 파일 크기를 비교
                    // 같으면 성공 메지시를 보냄
                    MessageUtil.Send(stream, result_Msg);

                else
                {
                    result_Msg.Body = new BodyResult()
                    {
                        MSGID = request_Msg.Header.MSGID,
                        RESULT = CONSTANTS.FAIL
                    };

                    // 파일 크기에 이상이 있다면 실패 메시지를 보냄
                    MessageUtil.Send(stream, result_Msg);
                }
                #endregion

                FileDownCompleteEvent?.Invoke(true, (fileSize / 1048576) + " MB / " + (fileSize / 1048576) + " MB");

                stream.Close();
                client.Close();

            }
            catch (Exception ex)
            {
                FileDownCompleteEvent?.Invoke(false, "");

                Console.WriteLine(ex);
                stream.Close();
                client.Close();
            }

        }


        public async void fileDownload(client_Message _message, FileStream _file, NetworkStream _stream, long _fileSize)
        {
            uint? dataMsgId = null;
            ushort prevSeq = 0;
            int percentCount = 0;
            long onePercent = _fileSize / 100;

            while (_message != null)
            {
                if (_message.Header.MSGTYPE != CONSTANTS.FILE_SEND_DATA)
                    break;

                if (dataMsgId == null)
                    dataMsgId = _message.Header.MSGID;
                else
                {
                    if (dataMsgId != _message.Header.MSGID)
                        break;
                }

                // 메시지 순서가 어긋나면 전송 중단
                if (prevSeq++ != _message.Header.SEQ)
                {
                    Console.WriteLine("{0}, {1}", prevSeq, _message.Header.SEQ);
                    break;
                }
                try
                {
                    _file.Write(_message.Body.GetBytes(), 0, _message.Body.GetSize());
                }
                catch (Exception e)
                {
                    _file.Close();
                    File.Delete(path);
                }

                percentCount++;

                if (percentCount == 2500)
                {
                    FildDownCurrent?.Invoke((int)(_file.Length / onePercent), (_fileSize / 1048576) + " MB / " + (_file.Length / 1048576) + " MB");
                    percentCount = 0;
                }
                // 분할 메시지가 아니면 반복을 한번만하고 빠져나옴
                if (_message.Header.FRAGMENTED == CONSTANTS.NOT_FRAGMENTED)
                    break;
                //마지막 메시지면 반복문을 빠져나옴
                if (_message.Header.LASTMSG == CONSTANTS.LASTMSG)
                    break;
                _message = await MessageUtil.ReceiveVideo(_stream);
            }
        }
        public static void Message_Set(Message_Type _type, client_Message _message, byte[] _fileName = null)
        {
            // request 메세지 일 경우,
            if (_type == Message_Type.req_Message)
            {
                _message.Body = new BodyRequest()
                {
                    FILENAME = _fileName,
                    FILESIZE = _fileName.Length
                };  // 메시지 (바디)

                _message.Header = new Header()
                {
                    MSGID = 0,
                    MSGTYPE = CONSTANTS.REQ_FILE_INFO,
                    BODYLEN = (uint)_message.Body.GetSize(),
                    FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                    LASTMSG = CONSTANTS.LASTMSG,
                    SEQ = 0
                };  // 메시지 (헤더)
            }

            // response 메세지 일 경우,
            else if (_type == Message_Type.resp_Message)
            {
                _message.Body = new BodyResponse()
                {
                    MSGID = _message.Header.MSGID,
                    RESPONSE = CONSTANTS.ACCEPTED
                };

                _message.Header = new Header()
                {
                    MSGID = msgid++,
                    MSGTYPE = CONSTANTS.REP_FILE_SEND,
                    BODYLEN = (uint)_message.Body.GetSize(),
                    FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                    LASTMSG = CONSTANTS.LASTMSG,
                    SEQ = 0
                };
            }

            // result 메세지 일 경우,
            else if (_type == Message_Type.result_Message)
            {
                _message.Body = new BodyResult()
                {
                    MSGID = _message.Header.MSGID,
                    RESULT = CONSTANTS.SUCCESS
                };
                _message.Header = new Header()
                {
                    MSGID = msgid++,
                    MSGTYPE = CONSTANTS.FILE_SEND_RES,
                    BODYLEN = (uint)_message.Body.GetSize(),
                    FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                    LASTMSG = CONSTANTS.LASTMSG,
                    SEQ = 0
                };  // result 메세지 헤더, 바디
            }
        }
        public struct ConnectInfo
        {
            public string fileName;
            public TcpClient client;
        }
        
    }
}