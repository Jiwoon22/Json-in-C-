﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;

namespace Logger_Lib
{
    #region 로그 정의서
    public enum Log_Type                   // 로그 변수명 구성 : 인덱스 + 관련 내용
    {
        // 시스템 로그 인덱스 = SYSTEM
        SYSTEM_START,                       // 로그 목적 : 시스템 시작 시간을 알기 위한 용도
        SYSTEM_END,                         // 로그 목적 : 시스템 종료 시간을 알기 위한 용도
        SYSTEM_STATE,                       // 로그 목적 : 현재 시스템 상태를 알기 위한 용도
        SYSTEM_SET_MODIFICATION,            // 로그 목적 : 시스템 설정 변경 이력을 알기 위한 용도
        SYSTEM_NETWORK_STATE,               // 로그 목적 : 시스템 네트워크 상태를 알기 위한 용도

        // 디버그 로그 인덱스 = DEBUG
        DEBUG_ERROR,                        // 로그 목적 : 프로그램 에러를 파악하기 위한 용도
        DEBUG_WARN,                         // 로그 목적 : 에러를 발생시킬 수 있는, 위험 요소를 파악하기 위한 용도

        // 채널 이벤트 로그 인덱스 = CH
        CH_REC_START,                       // 로그 목적 : 현재 채널의 녹화 시작 시간을 알기 위한 용도
        CH_REC_END,                         // 로그 목적 : 현재 채널의 녹화 종료 시간을 알기 위한 용도
        CH_EVENT_RCV,                       // 로그 목적 : 현재 채널이 수신한 이벤트 관련 정보를 알기 위한 용도
        CH_COPY,                            // 로그 목적 : 현재 채널의 백업 파일을 COPY한 이력을 알기 위한 용도
        CH_SET_MODIFICATION,                // 로그 목적 : 현재 채널의 설정 변경 이력을 알기 위한 용도
        CH_REC_FILE_UPLOAD
    }
    public enum Read_Log_Type {

        SYSTEM_START,
        SYSTEM_END,
        SYSTEM_STATE,
        SYSTEM_SET_MODIFICATION,
        SYSTEM_NETWORK_STATE,

        DEBUG_ERROR,
        DEBUG_WARN,

        CH_REC_START,
        CH_REC_END,
        CH_EVENT_RCV,
        CH_COPY,
        CH_SET_MODIFICATION,
        CH_REC_FILE_UPLOAD,
        ALL
    }
    #endregion
    public class Logger
    {
        static string path = @"C:\Users\CNSI-JJW\OneDrive\바탕 화면\로그\" + DateTime.Today.ToShortDateString() + ".txt";

        public static List<string> Log = new List<string>();

        static readonly ReaderWriterLockSlim rwLock = new ReaderWriterLockSlim();
        
        #region 로그 기록
        public static void Write(Log_Type _type, int _channel = 0, string content = "특이사항 없음")
        {

            #region Add 하기 전, 연산
            if (_type.ToString().Contains("DEBUG") | _type.ToString().Contains("SYSTEM"))
            {
                _channel = 0;
            }

            // 채널 로그인데, 채널 입력이 비정상적으로 입력됐을 경우 '777'이라는 임의의 채널을 입력해서 비정상 채널 입력에 대한 로그 남김
            else if (_type.ToString().Contains("CH") && _channel > 30 | _channel < 0)
            {
                return;
            }

            string time = DateTime.Now.ToString("HH:mm:ss");

            string Adding_log = time + " " + _channel.ToString() + " " + _type.ToString() + " " + content;
            #endregion
           
            try
            {
                rwLock.EnterWriteLock();
                using (var fileStream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read))
                using (var streamWriter = new StreamWriter(fileStream))
                {
                    streamWriter.WriteLine(Adding_log);
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                rwLock.ExitWriteLock();
            }
        }

    
    // File에 바로 적으면 write가 동시에 발생했을 때, 동기화 문제가 발생할 수 있기 때문에 쓰레드를 사용해야 한다.

        #endregion


        #region 로그 조회

        // 채널과 타입 별 조회
        public static string[] Read(Read_Log_Type _type)
        {
            string[] Logs = getLogFile();

            if (_type == Read_Log_Type.ALL)
            {
                return Logs;
            }
            else
            {
                return Array.FindAll(Logs, x => x.Split(' ')[2]==_type.ToString());
            }
        }

        public static string[] Read(Read_Log_Type _type, int _channel)
        {
            string[] Logs = getLogFile();

            if (_channel<0 || _channel > 30)
            {
                string[] Error_msg = new string[] { "올바른 채널을 입력해주세요" };
                return Error_msg;
            }
            
            if (_type == Read_Log_Type.ALL)
            {
                 return Array.FindAll(Logs, x => int.Parse(x.Split(' ')[1]) == _channel);   // 채널 파싱
            }

            else if (_type.ToString().Contains("DEBUG") | _type.ToString().Contains("SYSTEM"))
            {
                _channel = 0;
                Logs = Array.FindAll(Logs, x => x.Split(' ')[2] == _type.ToString());   // 타입 파싱
                return Array.FindAll(Logs, x => x.Split(' ')[1] == _channel.ToString());    // 채널 파싱
            }
            else
            {
                Logs = Array.FindAll(Logs, x => x.Split(' ')[2] == _type.ToString());   // 타입 파싱
                return Array.FindAll(Logs, x => x.Split(' ')[1] == _channel.ToString());    // 채널 파싱
            }
        }
        private static string[] getLogFile()
        {
            string[] _originLogFile;
            try
            {
                rwLock.EnterReadLock();
                using (var fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var streamReader = new StreamReader(fileStream))
                {
                    _originLogFile = streamReader.ReadToEnd().Split(new[] { Environment.NewLine }, StringSplitOptions.None);
                }
            }
            finally
            {
                rwLock.ExitReadLock();
            }
            

            string[] _deleteEndLineLogFile = new string[_originLogFile.Length - 1];
            Array.Copy(_originLogFile, _deleteEndLineLogFile, _originLogFile.Length - 1);

            return _deleteEndLineLogFile;
        }
        #endregion

    }
}
