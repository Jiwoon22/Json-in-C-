﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Logger_Lib;
namespace READ_TEST
{
    class Program
    {
        static object obj = new object();

        static void Main(string[] args)
        {
            //string path = @"C:\Users\user\Desktop\새 폴더\" + DateTime.Today.ToShortDateString() + ".txt";
            //string[] lines;

            //using (var fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            //using (var streamReader = new StreamReader(fileStream))
            //{
            //    lines = streamReader.ReadToEnd().Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            //}
            //lines = logger.Read(Read_Log_Type.ALL);
            //foreach (var line in lines)
            //{
            //    Console.WriteLine(line);
            //}
            
            string[] lines;
            lines = Logger.Read(Read_Log_Type.DEBUG_ERROR);
            for (int i = 0; i < lines.Length; i++)
            {
                Console.WriteLine(lines[i]);
            }
            //string path = @"C:\Users\CNSI-JJW\OneDrive\바탕 화면\로그\" + DateTime.Today.ToShortDateString() + ".txt";
            //string[] Log;

            //using (var fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            //using (var streamReader = new StreamReader(fileStream))
            //{
            //    Log = streamReader.ReadToEnd().Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            //}
            //Console.WriteLine(Log[1]);
            //string[] Log2 = File.ReadAllLines(path);
            //Console.WriteLine(Log2[1]);
        }
        
    }

}
