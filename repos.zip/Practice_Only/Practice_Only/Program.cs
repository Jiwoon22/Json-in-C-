﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Threading;
using Logger_Lib;

namespace Practice_Only
{
    class Program
    {
        static object fileWriteLock = new object();
        private static object lockObject = new object();
        
        static void Main()
        {
            #region 로그 테스트
            Thread t1 = new Thread(() =>
            {

                for (int i = 0; i < 10000; i++)
                {
                    Logger.Write(Log_Type.CH_EVENT_RCV, 1);
                    Thread.Sleep(10);
                }

                Console.WriteLine("1번 종료");
            });
            Thread t2 = new Thread(() =>
            {

                for (int i = 0; i < 10000; i++)
                {
                    Logger.Write(Log_Type.CH_COPY, 2);
                    Thread.Sleep(10);
                }
                Console.WriteLine("2번 종료");
            });
            Thread t3 = new Thread(() =>
            {

                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.DEBUG_ERROR, 0, "특이사항 작성됐음");
                    Thread.Sleep(100);
                }
                Console.WriteLine("3번 종료");
            });
            Thread t4 = new Thread(() =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.DEBUG_WARN, 4, "왈닝 작성됐음");
                    Thread.Sleep(50);
                }
                Console.WriteLine("4번 종료");
            });
            Thread t5 = new Thread(() =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.SYSTEM_NETWORK_STATE, 5);
                    Thread.Sleep(10);
                }
                Console.WriteLine("5번 종료");
            });
            Thread t6 = new Thread(() =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.CH_EVENT_RCV, 6);
                    Thread.Sleep(30);
                }
                Console.WriteLine("6번 종료");
            });
            Thread t7 = new Thread(() =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.CH_EVENT_RCV, 7);
                    Thread.Sleep(20);
                }
                Console.WriteLine("7번 종료");
            });
            Thread t8 = new Thread(() =>
            {
                for (int i = 0; i < 500; i++)
                {
                    Logger.Write(Log_Type.CH_REC_FILE_UPLOAD, 8);
                    Thread.Sleep(160);
                }
                Console.WriteLine("8번 종료");
            });
            Thread t9 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.SYSTEM_START, 9);
                    Thread.Sleep(100);
                }
                Console.WriteLine("9번 종료");
            });
            Thread t10 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.SYSTEM_STATE, 10, "시스템 상태 확인");
                    Thread.Sleep(100);
                }
                Console.WriteLine("10번 종료");
            });
            //25700
            Thread t11 = new Thread(() =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.CH_REC_START, 11, "5번 채널 녹화시작");
                    Thread.Sleep(50);
                }
                Console.WriteLine("11번 종료");
            });
            Thread t12 = new Thread(() =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.CH_REC_END, 12);
                    Thread.Sleep(20);
                }
                Console.WriteLine("12번 종료");
            });
            Thread t13 = new Thread(() =>
            {

                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.CH_EVENT_RCV, 13);
                    Thread.Sleep(100);
                }

                Console.WriteLine("13번 종료");
            });
            Thread t14 = new Thread(() =>
            {

                for (int i = 0; i < 1000; i++)
                {
                    Logger.Write(Log_Type.CH_COPY, 14);
                    Thread.Sleep(30);
                }
                Console.WriteLine("14번 종료");
            });
            Thread t15 = new Thread(() =>
            {

                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.DEBUG_ERROR, 0, "특이사항 작성됐음");
                    Thread.Sleep(50);
                }
                Console.WriteLine("15번 종료");
            });
            Thread t16 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.DEBUG_WARN, 16, "왈닝 작성됐음");
                    Thread.Sleep(1000);
                }
                Console.WriteLine("16번 종료");
            });
            Thread t17 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.SYSTEM_NETWORK_STATE, 17);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("17번 종료");
            });
            Thread t18 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_EVENT_RCV, 18);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("18번 종료");
            });
            Thread t19 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_EVENT_RCV, 19);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("19번 종료");
            });
            Thread t20 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_REC_FILE_UPLOAD, 20);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("20번 종료");
            });
            Thread t21 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.SYSTEM_START, 21);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("21번 종료");
            });
            Thread t22 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.SYSTEM_STATE, 22, "시스템 상태 확인");
                    Thread.Sleep(1000);
                }
                Console.WriteLine("22번 종료");
            });
            Thread t23 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_REC_START, 23, "5번 채널 녹화시작");
                    Thread.Sleep(1000);
                }
                Console.WriteLine("23번 종료");
            });
            Thread t24 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_REC_END, 24);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("24번 종료");
            });
            Thread t25 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_EVENT_RCV, 25);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("25번 종료");
            });
            Thread t26 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_REC_FILE_UPLOAD, 26);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("26번 종료");
            });
            Thread t27 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.SYSTEM_START, 27);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("27번 종료");
            });
            Thread t28 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.SYSTEM_STATE, 28, "시스템 상태 확인");
                    Thread.Sleep(1000);
                }
                Console.WriteLine("28번 종료");
            });
            Thread t29 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_REC_START, 29, "5번 채널 녹화시작");
                    Thread.Sleep(1000);
                }
                Console.WriteLine("29번 종료");
            });
            Thread t30 = new Thread(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Logger.Write(Log_Type.CH_REC_END, 30);
                    Thread.Sleep(1000);
                }
                Console.WriteLine("30번 종료");
            });
            // 31300

            t1.Start();
            t2.Start();
            t3.Start();
            t4.Start();
            t5.Start();
            t6.Start();
            t7.Start();
            t8.Start();
            t9.Start();
            t10.Start();
            t11.Start();
            t12.Start();
            t13.Start();
            t14.Start();
            t15.Start();
            t16.Start();
            t17.Start();
            t18.Start();
            t19.Start();
            t20.Start();
            t21.Start();
            t22.Start();
            t23.Start();
            t24.Start();
            t25.Start();
            t26.Start();
            t27.Start();
            t28.Start();
            t29.Start();
            t30.Start();

            AppDomain.CurrentDomain.ProcessExit += (sender, e) =>
            {
                t1.Abort();
                t2.Abort();
                t3.Abort();
                t4.Abort();
                t5.Abort();
                t6.Abort();
                t7.Abort();
                t8.Abort();
                t9.Abort();
                t10.Abort();
                t11.Abort();
                t12.Abort();
                t13.Abort();
                t14.Abort();
                t15.Abort();
                t16.Abort();
                t17.Abort();
                t18.Abort();
                t19.Abort();
                t20.Abort();
                t21.Abort();
                t22.Abort();
                t23.Abort();
                t24.Abort();
                t25.Abort();
                t26.Abort();
                t27.Abort();
                t28.Abort();
                t29.Abort();
                t30.Abort();
            };
            #endregion

            Thread.Sleep(15000);
            Thread readT = new Thread(() =>
            {
                string[] log = Logger.Read(Read_Log_Type.CH_COPY);
                for (int i = 0; i < log.Length; i++)
                {
                    Console.WriteLine(log[i]);
                }
            });

            readT.Start();
            //로그 Read 테스트
            


        }
       

    }
}
