﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Filter_Info_Class;
using ClassLibrary1;

namespace WpfApp1
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
       
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Class1 test = new Class1();
            filter_info_class filter_info_obj = new filter_info_class();

            string checklist="";

            if (string.IsNullOrEmpty(StartDateBox.Text))
            {
                MessageBox.Show("날짜를 선택해주세요");
            }

            else
            {
                // checkbox 조건 리스트 생성
                foreach (CheckBox check in grid.Children.OfType<CheckBox>())
                {
                    if (check.IsChecked == true)
                    {
                        checklist += check.Content.ToString();
                    }
                }

                string start_date = StartDateBox.Text;
                string end_date = EndDateBox.Text;

                // 기간에 맞는 log 파일 불러오기
                string[] readLog = test.read(start_date);

                LogContentBox.Clear();

                // filter 정보를 obj 객체에 담기
                filter_info_obj.type = typeInput.Text;
                filter_info_obj.chNum = checklist;

                // filt 시간을 담은 객체를 read 라이브러리에 전달
                string[] hourFilter = test.Log_Filter(readLog, filter_info_obj);

                // log 출력
                for (int i = 0; i < hourFilter.Length; i++)
                {
                      LogContentBox.AppendText(hourFilter[i] + "\n");
                }
            }
        }

        private void LogContentBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void Testtextbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
