﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Logger_Lib
{
    public enum Log_Type
    {
        SYSTEM,
        DEBUG,
        OPERATION,
        NONE
    }
    public enum Sys_Log
    {
        START,
        STOP,
        SETMOD,
        INFO,
        NETWORK,
        NONE
    }
    public enum Debug_Log
    {
        WARN,
        ERROR,
        NONE
    }
    public enum Op_Log
    {
        REC_START,
        REC_END,
        EVENT_RCV,
        COPY,
        UPLOAD,
        NONE
    }

    public class Logger
    {

        public string fileName = @"C:\Users\CNSI-JJW\OneDrive\바탕 화면\로그\" + DateTime.Today.ToShortDateString() + ".txt";

        static List<string[]> Log = new List<string[]>();

        public void write()
        {
            File.AppendAllText(fileName,, Encoding.Default);
        }
        private void Log_Write(Log_Type _type, Debug_Log _debug, string error_msg)  // 타입이 DEBUG 일 경우,
        {
            switch (_type)
            {
                case Log_Type.DEBUG:
                    Log.Add(DateTime.Now.ToString("hh:MM:ss") + " 0 " + 
                    break;
            }
        }

    }
}
