﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Filter_Info_Class;

namespace ClassLibrary1
{
    public class Class1
    {
        private string _path = @"C:\Users\CNSI-JJW\OneDrive\바탕 화면\로그\";

        public string[] read(string Start_Date)
        {
            string LogLocatioin = _path + Start_Date + ".txt";
            string[] readLog = File.ReadAllLines(LogLocatioin, Encoding.Default);

            return readLog;

        }
        // 처음 read, 전체 read
        public string[] read(string Start_Date, string End_Date)
        {
            string LogLocatioin = _path + Start_Date + ".txt";
            string[] readLog = File.ReadAllLines(LogLocatioin, Encoding.Default);

            return readLog;

        }
        
        static string[] CombineArrays(string[] array1, string[] array2)
        {
            // 새로운 배열의 크기 계산
            int newSize = array1.Length + array2.Length;

            // 새로운 배열 생성
            string[] combinedArray = new string[newSize];

            // 기존 배열 복사
            Array.Copy(array1, combinedArray, array1.Length);

            // 새로운 배열에 두 번째 배열 추가
            Array.Copy(array2, 0, combinedArray, array1.Length, array2.Length);

            return combinedArray;
        }
        // 시간 filter
        public string[] Log_Filter(string[] BeforeFilterLog, filter_info_class filter)
        {
            string[] AfterFilterLog = BeforeFilterLog;

            
            if (filter.type != "")
            {
                if (filter.type == "전체")
                {
                    AfterFilterLog = AfterFilterLog;
                }
                else
                {
                    AfterFilterLog = Array.FindAll(AfterFilterLog, x => ((x.Split(' ')[2]) == filter.type));
                }
            }

            if (filter.chNum.Length>0)
            {
                string[] result=new string[] { };
                foreach (string chnumber in filter.chNum.Split(' '))
                {
                    result = CombineArrays(result, Array.FindAll(AfterFilterLog, x => ((x.Split(' ')[1]) == chnumber)));
                }
                AfterFilterLog = result;
            }
            return AfterFilterLog;
            
        }
     
    }
}
