﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Log_Write_Library
{
    enum log_content
    {
        Time,
        Ch_Num,
        Type,
        Category
    }
    public class log_writter
    {
        public void write(log_content., string content)
        {
            string fileName = @"C:\Users\CNSI-JJW\OneDrive\바탕 화면\로그\" + DateTime.Today.ToShortDateString() + ".txt";

            if (!File.Exists(fileName))
            {
                StreamWriter writer = new StreamWriter(fileName);
                writer.WriteLine(content);
                writer.Close();
            }
            else
            {
                StreamWriter writer = File.AppendText(fileName);
                writer.WriteLine(content);
                writer.Close();
            }
        }
        public void write(string save_location, string content)
        {
            string fileName = save_location + DateTime.Today.ToShortDateString() + ".txt";

            if (!File.Exists(fileName))
            {
                StreamWriter writer = new StreamWriter(fileName);
                writer.WriteLine(content);
                writer.Close();
            }
            else
            {
                StreamWriter writer = File.AppendText(fileName);
                writer.WriteLine(content);
                writer.Close();
            }
        }
    }
}

