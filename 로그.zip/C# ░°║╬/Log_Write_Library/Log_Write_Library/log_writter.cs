﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Log_Write_Library
{
    public enum Log_Type
    {
        DEBUG,
        OPERATION
    }
    public enum Log_Category
    {
        REC_ALL,
        UPLOAD,
        REC_EVENT
    }
    public class log_writter
    {
        
        public void write(int ch_num, Log_Type type, Log_Category category)
        {
            string fileName = @"C:\Users\user\Desktop\C# 공부\" + DateTime.Today.ToShortDateString() + ".txt";

            if (!File.Exists(fileName))
            {
                StreamWriter writer = new StreamWriter(fileName);

                string Log = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss ") + ch_num.ToString();
                
                switch (type)
                {
                    case Log_Type.DEBUG:
                        Log += " DEBUG ";
                        break;

                    case Log_Type.OPERATION:
                        Log += " OPERATION ";
                        break;
                }

                switch (category)
                {
                    case Log_Category.REC_ALL:
                        Log += "REC_ALL ";
                        break;

                    case Log_Category.UPLOAD:
                        Log += "UPLOAD ";
                        break;
                    case Log_Category.REC_EVENT:
                        Log += "REC_EVENT ";
                        break;
                }
                writer.WriteLine(Log);
                writer.Close();
            }
            else
            {
                StreamWriter writer = File.AppendText(fileName);

                string Log = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss ") + ch_num.ToString();

                switch (type)
                {
                    case Log_Type.DEBUG:
                        Log += " DEBUG ";
                        break;

                    case Log_Type.OPERATION:
                        Log += " OPERATION ";
                        break;
                }

                switch (category)
                {
                    case Log_Category.REC_ALL:
                        Log += "REC_ALL ";
                        break;

                    case Log_Category.UPLOAD:
                        Log += "UPLOAD ";
                        break;
                    case Log_Category.REC_EVENT:
                        Log += "REC_EVENT ";
                        break;
                }
                writer.WriteLine(Log);
                writer.Close();
               
            }
        }
        /*public void write(string save_location, string content)
        {
            string fileName = save_location + DateTime.Today.ToShortDateString() + ".txt";

            if (!File.Exists(fileName))
            {
                StreamWriter writer = new StreamWriter(fileName);
                writer.WriteLine(content);
                writer.Close();
            }
            else
            {
                StreamWriter writer = File.AppendText(fileName);
                writer.WriteLine(content);
                writer.Close();
            }
        }*/
    }
}

