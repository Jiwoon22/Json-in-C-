﻿using System;
using System.Runtime.InteropServices;
using Log_Write_Library;

class player
{
    static void Main()
    {
        log_writter test = new log_writter();
        test.write(3, Log_Type.DEBUG, Log_Category.REC_EVENT);
        test.write(3, Log_Type.OPERATION, Log_Category.UPLOAD);
        Console.WriteLine("gkgk");
    }
}