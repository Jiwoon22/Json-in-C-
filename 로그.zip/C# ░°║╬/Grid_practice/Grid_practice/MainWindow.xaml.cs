﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Grid_practice
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            /*string p = "test";
            for(int i = 0; i < 20; i++)
            {

                user_list.Items.Add("1"+p);
            }
            user_list.SelectedIndex = user_list.Items.Count - 1;
            user_list.ScrollIntoView(user_list.SelectedItem);
            for (int i = 0; i < 20; i++)
            {

                log_list.Items.Add("1" + p);
            }
            log_list.SelectedIndex = user_list.Items.Count - 1;
            log_list.ScrollIntoView(user_list.SelectedItem);*/


        }

        private void Login_list_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Login_list_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox check in check_grid.Children.OfType<CheckBox>())
            {

            }
            

        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox check in check_grid.Children.OfType<CheckBox>())
            {

                check.IsChecked = false;

            }
        }

        private void all_check_off(object sender, RoutedEventArgs e)
        {
            all.IsChecked = false;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
        }

    
    }
}
