﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Filter_Info_Class
{
    public class filter_info_class
    {
        private string Type;
        private string ChNum;
        private string Category;
        
        
        public string type
        {
            get { return Type; }
            set { Type = value; }
        }
        public string chNum
        {
            get { return ChNum; }
            set { ChNum = value; }
        }
        public string category
        {
            get { return Category; }
            set { Category = value; }
        }
    }
}
