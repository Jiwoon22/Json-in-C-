﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;
namespace CMSHttpServer
{
    class FileTransfer
    {
        const int port = 9003;
        public delegate void FileDownComplit(bool complit, string complitMsg);
        public delegate void CurrentFileDownState(int percent, string totalPerCurrent);

        public event FileDownComplit FileDownComplitEvent;
        public event CurrentFileDownState FildDownCurrent;
        public FileTransfer()
        {


        }
        public void stop()
        {
            try
            {

            }
            catch (Exception ex)
            {

            }
        }
        public void setFilePath(string _path)
        {
            path = _path;
        }
        string path;
        uint msgid = 0;


        public void Down(string _fileUrl, string _url = "192.168.219.104")
        {
            string url = _url;
            IPEndPoint clientAddress = new IPEndPoint(0, 0);
            IPEndPoint serverAdress = new IPEndPoint(IPAddress.Parse(url), port);

            TcpClient client = null;
            try
            {
                ConnectInfo info = new ConnectInfo();
                client = new TcpClient(clientAddress);
                info.client = client;
                info.fileName = _fileUrl;
                client.BeginConnect(url, port, new AsyncCallback(filedownloadstartCallback), info);
            }
            catch (Exception ex)
            {
                if (client != null) client.Close();
            }
        }
        private async void filedownloadstartCallback(IAsyncResult _responeResult)
        {
            ConnectInfo info = (ConnectInfo)_responeResult.AsyncState;
            TcpClient client = info.client;
            string filepath = info.fileName;

            NetworkStream stream = null;
            FileStream file = null;

            try
            {
                stream = client.GetStream();
                uint msgId = 0;
                Message reqMsg = new Message();
                byte[] fileName = Encoding.Default.GetBytes(filepath);
                reqMsg.Body = new BodyRequest()
                {
                    FILENAME = fileName,
                    FILESIZE = fileName.Length
                };

                reqMsg.Header = new Header()
                {
                    MSGID = 0,
                    MSGTYPE = CONSTANTS.REQ_FILE_INFO,
                    BODYLEN = (uint)reqMsg.Body.GetSize(),
                    FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                    LASTMSG = CONSTANTS.LASTMSG,
                    SEQ = 0
                };
                MessageUtil.Send(stream, reqMsg);

                reqMsg = await MessageUtil.ReceiveVideo(stream); //2

                if (reqMsg.Header.MSGTYPE != CONSTANTS.REQ_FILE_SEND)//파일 없음 or 전송 시작 시퀀스 예외발생
                {
                    if (FileDownComplitEvent != null)
                        FileDownComplitEvent(false, "");
                    stream.Close();
                    client.Close();
                    return;
                }

                BodyRequest reqBody = (BodyRequest)reqMsg.Body;

                Message rspMsg = new Message();
                rspMsg.Body = new BodyResponse()
                {
                    MSGID = reqMsg.Header.MSGID,
                    RESPONSE = CONSTANTS.ACCEPTED
                };

                rspMsg.Header = new Header()
                {
                    MSGID = msgid++,
                    MSGTYPE = CONSTANTS.REP_FILE_SEND,
                    BODYLEN = (uint)rspMsg.Body.GetSize(),
                    FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                    LASTMSG = CONSTANTS.LASTMSG,
                    SEQ = 0
                };

                MessageUtil.Send(stream, rspMsg);
                long fileSize = reqBody.FILESIZE;
                //string fileName = Encoding.Default.GetString(reqBody.FILENAME);

                // 파일 스트림 생성
                file = new FileStream(path, FileMode.Create);

                uint? dataMsgId = null;
                ushort prevSeq = 0;
                int percentCount = 0;
                long onePercent = fileSize / 100;
                reqMsg = await MessageUtil.ReceiveVideo(stream);
                while (reqMsg != null)
                {
                    if (reqMsg.Header.MSGTYPE != CONSTANTS.FILE_SEND_DATA)
                        break;

                    if (dataMsgId == null)
                        dataMsgId = reqMsg.Header.MSGID;
                    else
                    {
                        if (dataMsgId != reqMsg.Header.MSGID)
                            break;
                    }

                    // 메시지 순서가 어긋나면 전송 중단
                    if (prevSeq++ != reqMsg.Header.SEQ)
                    {
                        Console.WriteLine("{0}, {1}", prevSeq, reqMsg.Header.SEQ);
                        break;
                    }
                    try
                    {
                        file.Write(reqMsg.Body.GetBytes(), 0, reqMsg.Body.GetSize());
                    }
                    catch (Exception e)
                    {
                        file.Close();
                        File.Delete(path);
                    }

                    percentCount++;

                    if (percentCount == 2500)
                    {
                        if (FildDownCurrent != null)
                        {

                            FildDownCurrent((int)(file.Length / onePercent), (fileSize / 1048576) + " MB / " + (file.Length / 1048576) + " MB");
                        }
                        percentCount = 0;
                    }
                    // 분할 메시지가 아니면 반복을 한번만하고 빠져나옴
                    if (reqMsg.Header.FRAGMENTED == CONSTANTS.NOT_FRAGMENTED)
                        break;
                    //마지막 메시지면 반복문을 빠져나옴
                    if (reqMsg.Header.LASTMSG == CONSTANTS.LASTMSG)
                        break;
                    reqMsg = await MessageUtil.ReceiveVideo(stream);
                    
                }
                long recvFileSize = file.Length;
                file.Close();

                Console.WriteLine();
                Console.WriteLine("수신 파일 크기 : {0} bytes", recvFileSize);

                Message rstMsg = new Message();
                rstMsg.Body = new BodyResult()
                {
                    MSGID = reqMsg.Header.MSGID,
                    RESULT = CONSTANTS.SUCCESS
                };
                rstMsg.Header = new Header()
                {
                    MSGID = msgid++,
                    MSGTYPE = CONSTANTS.FILE_SEND_RES,
                    BODYLEN = (uint)rstMsg.Body.GetSize(),
                    FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                    LASTMSG = CONSTANTS.LASTMSG,
                    SEQ = 0
                };

                if (fileSize == recvFileSize)
                {
                    // 파일 전송 요청에 담겨온 파일 크기와 실제로 받은 파일 크기를 비교
                    // 같으면 성공 메지시를 보냄
                    MessageUtil.Send(stream, rstMsg);
                }
                else
                {
                    rstMsg.Body = new BodyResult()
                    {
                        MSGID = reqMsg.Header.MSGID,
                        RESULT = CONSTANTS.FAIL
                    };

                    // 파일 크기에 이상이 있다면 실패 메시지를 보냄
                    MessageUtil.Send(stream, rstMsg);
                }

                if (FileDownComplitEvent != null)
                    FileDownComplitEvent(true, (fileSize / 1048576) + " MB / " + (fileSize / 1048576) + " MB");

                stream.Close();
                client.Close();

            }
            catch (Exception ex)
            {
                if (FileDownComplitEvent != null)
                    FileDownComplitEvent(false, "");

                Console.WriteLine(ex);
                stream.Close();
                client.Close();
            }


        }
    }


    public struct ConnectInfo
    {
        public string fileName;
        public TcpClient client;
    }
    
}

