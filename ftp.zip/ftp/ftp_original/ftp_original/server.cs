﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;
using ftp_server;

namespace CMSHttpServer
{
    public class FileTransfer
    {
        public struct ConnectInfo
        {
            public string fileName;
            public TcpClient client;
        }
        const int CHUNK_SIZE = 4096;
        const int port = 9003;
        TcpListener server = null;
        public FileTransfer()
        {
        }

        public void sendStart()
        {
            Thread th = new Thread(() =>
            {
                TcpListen();
            });
            th.Start();
        }
        bool flag = true;
        void TcpListen()
        {
            try
            {
                IPEndPoint localAddress = new IPEndPoint(0, port);

                server = new TcpListener(localAddress);
                server.Start(20);

                while (flag)
                {
                    try
                    {
                        TcpClient client = server.AcceptTcpClient();
                         Thread th = new Thread(() =>
                        {
                            HandleClientAsync(client);
                        });
                        th.Name = "send";
                        th.Priority = ThreadPriority.Normal;
                        th.Start();

                    }
                    catch (Exception ex)
                    {
                    }

                }
                flag = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);

            }
        }

        async Task HandleClientAsync(TcpClient tc)
        {
            TcpClient client = tc;
            NetworkStream stream = null;

            Stream fileStream = null;
            try
            {
                stream = client.GetStream();
                stream.ReadTimeout = 5000;
                uint msgId = 0;
                Message reqMsg = await MessageUtil.Receive(stream);//1.파일 전송 요청 받기

                if (reqMsg.Header.MSGTYPE != CONSTANTS.REQ_FILE_INFO)
                {
                    stream.Close();
                    client.Close();
                    return;
                }

                string fileName = Encoding.Default.GetString(reqMsg.Body.GetBytes());

                if (!File.Exists(fileName))
                {
                    reqMsg.Body = new BodyRequest()
                    {
                        FILESIZE = 0,
                        FILENAME = Encoding.Default.GetBytes("")
                    };

                    reqMsg.Header = new Header()
                    {
                        MSGID = msgId++,
                        MSGTYPE = CONSTANTS.FILE_NONE_EXIST,
                        BODYLEN = (uint)reqMsg.Body.GetSize(),
                        FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                        LASTMSG = CONSTANTS.LASTMSG,
                        SEQ = 0
                    };
                    MessageUtil.Send(stream, reqMsg); //1-2
                    stream.Close();
                    client.Close();
                    return;
                }
                else
                {
                    FileInfo fileInfo = new FileInfo(fileName);
                    if (fileInfo.Length == 0)
                    {
                        stream.Close();
                        client.Close();
                        return;
                    }
                    reqMsg.Body = new BodyRequest()
                    {
                        FILESIZE = new FileInfo(fileName).Length,
                        FILENAME = Encoding.Default.GetBytes("")
                    };
                    reqMsg.Header = new Header()
                    {
                        MSGID = msgId++,
                        MSGTYPE = CONSTANTS.REQ_FILE_SEND,
                        BODYLEN = (uint)reqMsg.Body.GetSize(),
                        FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                        LASTMSG = CONSTANTS.LASTMSG,
                        SEQ = 0
                    };
                }


                // 클라이언트는 서버에 접속하자마자 파일 전송 요청 메시지를 보냄
                MessageUtil.Send(stream, reqMsg); //1-2
                Message rspMsg = await MessageUtil.Receive(stream);//4
                if (rspMsg.Header.MSGTYPE != CONSTANTS.REP_FILE_SEND)
                {
                    Console.WriteLine("정상적인 서버 응답이 아닙니다.{0}", rspMsg.Header.MSGTYPE);
                    stream.Close();
                    client.Close();
                    return;
                }

                if (((BodyResponse)rspMsg.Body).RESPONSE == CONSTANTS.DENIED)
                {
                    Console.WriteLine("서버에서 파일 전송을 거부했습니다.");
                    stream.Close();
                    client.Close();
                    return;
                }

                fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                {
                    byte[] rbytes = new byte[CHUNK_SIZE];

                    long readValue = BitConverter.ToInt64(rbytes, 0);

                    int totalRead = 0;
                    ushort msgSeq = 0;
                    byte fragmented = (fileStream.Length < CHUNK_SIZE) ? CONSTANTS.NOT_FRAGMENTED : CONSTANTS.FRAGMENTE;
                    while (totalRead < fileStream.Length)
                    {
                        int read = fileStream.Read(rbytes, 0, CHUNK_SIZE);  //read는 다운하고자 하는 파일을 4096씩만틈 읽어서 rbytes 배열에 저장한다.
                        totalRead += read;
                        Message fileMsg = new Message();

                        byte[] sendBytes = new byte[read];
                        Array.Copy(rbytes, 0, sendBytes, 0, read);  //rbytes의 read만큼 sendBytes에 복사해라

                        fileMsg.Body = new BodyData(sendBytes);
                        fileMsg.Header = new Header()
                        {
                            MSGID = msgId,
                            MSGTYPE = CONSTANTS.FILE_SEND_DATA,
                            BODYLEN = (uint)fileMsg.Body.GetSize(),
                            FRAGMENTED = fragmented,
                            LASTMSG = (totalRead < fileStream.Length) ? CONSTANTS.NOT_LASTMSG : CONSTANTS.LASTMSG,
                            SEQ = msgSeq++
                        };

                        // 모든 파일의 내용이 전송될 때까지 파일 스트림을 0x03 메시지에 담아 서버로 보냄
                        MessageUtil.Send(stream, fileMsg);
                    }
                    // 서버에서 파일을 제대로 받았는지에 대한 응답을 받음
                    Message rstMsg = await MessageUtil.Receive(stream);
                    BodyResult result = ((BodyResult)rstMsg.Body);
                }
                if (fileStream != null) fileStream.Close();
                if (stream != null) stream.Close();
                if (client != null) client.Close();

                return;


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                if (fileStream != null) fileStream.Close();
                if (stream != null) stream.Close();
                client.Close();
            }
            return;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            FileTransfer server = new FileTransfer();
            server.sendStart();
        }
    }
}
