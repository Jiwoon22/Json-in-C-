﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace ftp_server
{
    public class ftp_server
    {
        public struct ConnectInfo
        {
            public string fileName;
            public TcpClient client;
        }
        const int CHUNK_SIZE = 4096;
        const int port = 9003;
        TcpListener server = null;
        public ftp_server()
        {
        }

        public void sendStart()
        {
            Thread th = new Thread(() =>
            {
                TcpListen();
            });
            th.Start();
        }
        bool flag = true;
        void TcpListen()    // 클라이언트 수신
        {
            try
            {
                IPEndPoint localAddress = new IPEndPoint(IPAddress.Parse("192.168.0.110"), port);

                server = new TcpListener(localAddress);
                server.Start(20);

                while (flag)
                {
                    try
                    {
                        TcpClient client = server.AcceptTcpClient();
                        Thread th = new Thread(() =>
                        {
                            Console.WriteLine("클라 접속함");
                            HandleClientAsync(client);
                        });
                        th.Name = "send";
                        th.Priority = ThreadPriority.Normal;
                        th.Start();

                    }
                    catch (Exception ex)
                    {
                    }

                }
                flag = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }       

        async Task HandleClientAsync(TcpClient _client)
        {
            TcpClient client = _client;
            NetworkStream stream = null;

            Stream fileStream = null;

            try
            {
                stream = client.GetStream();
                stream.ReadTimeout = 5000;
                uint msgId = 0;

                #region Request 메시지 수신
                Message reqMsg = await MessageUtil.Receive(stream);// 1. 클라이언트가 보내온 파일 전송 요청 메시지를 수신한다.
                #endregion

                if (reqMsg.Header.MSGTYPE != CONSTANTS.REQ_FILE_INFO)
                {
                    stream.Close();
                    client.Close(); 
                    return;
                }

                string fileName = @"C:\Users\CNSI-JJW\OneDrive\바탕 화면\로그";

                #region Request 응답 메시지 전송 (파일 존재 유무 Check)
                if (!File.Exists(fileName))
                {

                    Message_set(reqMsg, 0, msgId, CONSTANTS.FILE_NONE_EXIST);
                                        
                    MessageUtil.Send(stream, reqMsg); 
                    stream.Close();
                    client.Close();
                    return;
                }
                else
                {
                    FileInfo fileInfo = new FileInfo(fileName);
                    if (fileInfo.Length == 0)
                    {
                        stream.Close();
                        client.Close();
                        return;
                    }
                    long fileSize = new FileInfo(fileName).Length;
                    Message_set(reqMsg, fileSize, msgId, CONSTANTS.REP_FILE_SEND);
                }
                MessageUtil.Send(stream, reqMsg); //1-2
                #endregion

                #region Response 메시지 수신
                Message rspMsg = await MessageUtil.Receive(stream);//4
                #endregion



                if (rspMsg.Header.MSGTYPE != CONSTANTS.REP_FILE_SEND)
                {
                    Console.WriteLine("정상적인 서버 응답이 아닙니다.{0}", rspMsg.Header.MSGTYPE);
                    stream.Close();
                    client.Close();
                    return;
                }

                if (((BodyResponse)rspMsg.Body).RESPONSE == CONSTANTS.DENIED)
                {
                    Console.WriteLine("서버에서 파일 전송을 거부했습니다.");
                    stream.Close();
                    client.Close();
                    return;
                }


                fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                {
                    #region 파일 전송
                    fileSend(fileStream, stream, fileName, msgId);
                    #endregion

                    #region Result 메세지 수신
                    // 서버에서 파일을 제대로 받았는지에 대한 응답을 받음
                    Message rstMsg = await MessageUtil.Receive(stream);
                    #endregion

                    BodyResult result = ((BodyResult)rstMsg.Body);
                }
                if (fileStream != null) fileStream.Close();
                if (stream != null) stream.Close();
                if (client != null) client.Close();

                return;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                if (fileStream != null) fileStream.Close();
                if (stream != null) stream.Close();
                client.Close();
            }
            return;
        }
       
        // 파일 전송 method
        public void fileSend(Stream _fileStream, NetworkStream _stream ,string _fileName, uint _msgid)
        {
            byte[] rbytes = new byte[CHUNK_SIZE];   // CHUNK_SIZE = 4906

            long readValue = BitConverter.ToInt64(rbytes, 0);

            int totalRead = 0;
            ushort msgSeq = 0;
            byte fragmented = (_fileStream.Length < CHUNK_SIZE) ? CONSTANTS.NOT_FRAGMENTED : CONSTANTS.FRAGMENTE;

            while (totalRead < _fileStream.Length)
            {
                int read = _fileStream.Read(rbytes, 0, CHUNK_SIZE);
                totalRead += read;
                Message fileMsg = new Message();

                byte[] sendBytes = new byte[read];
                Array.Copy(rbytes, 0, sendBytes, 0, read);

                fileMsg.Body = new BodyData(sendBytes);
                fileMsg.Header = new Header()
                {
                    MSGID = _msgid,
                    MSGTYPE = CONSTANTS.FILE_SEND_DATA,
                    BODYLEN = (uint)fileMsg.Body.GetSize(),
                    FRAGMENTED = fragmented,
                    LASTMSG = (totalRead < _fileStream.Length) ? CONSTANTS.NOT_LASTMSG : CONSTANTS.LASTMSG,
                    SEQ = msgSeq++
                };

                // 모든 파일의 내용이 전송될 때까지 파일 스트림을 0x03 메시지에 담아 서버로 보냄
                MessageUtil.Send(_stream, fileMsg);
            }
        }

        public void Message_set(Message _message, long _fileSize, uint _msgId, uint _msgtype)
        {
            _message.Body = new BodyRequest()
            {
                FILESIZE = _fileSize,
                FILENAME = Encoding.Default.GetBytes("")
            };
            _message.Header = new Header()
            {
                MSGID = _msgId++,
                MSGTYPE = _msgtype,
                BODYLEN = (uint)_message.Body.GetSize(),
                FRAGMENTED = CONSTANTS.NOT_FRAGMENTED,
                LASTMSG = CONSTANTS.LASTMSG,
                SEQ = 0
            };
        }
    }

    
}
